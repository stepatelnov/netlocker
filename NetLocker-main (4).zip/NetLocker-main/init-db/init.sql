-- Включаем расширение pgcrypto для использования функций хеширования
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Таблица для хранения информации об администраторах
CREATE TABLE IF NOT EXISTS administrators (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица для хранения статистики запросов к доменам и ресурсам
CREATE TABLE IF NOT EXISTS request_statistics (
    id SERIAL PRIMARY KEY,
    request_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source_ip INET NOT NULL,
    resource VARCHAR(255) NOT NULL
);

-- Таблица для хранения заблокированных IP и доменов
CREATE TABLE IF NOT EXISTS blocked_entities (
    id SERIAL PRIMARY KEY,
    blocked_ip INET,
    blocked_domain VARCHAR(255),
    resource VARCHAR(255),
    is_blocked BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT check_ip_or_domain CHECK (blocked_ip IS NOT NULL OR blocked_domain IS NOT NULL)
);

-- Добавляем администратора с хэшированным паролем
INSERT INTO administrators (username, password_hash)
VALUES
('admin', crypt('admin', gen_salt('bf')));
