from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from sqlalchemy.orm import Session
from database import request_statistics, blocked_entities, get_db
from auth.password_utils import authenticate_user, get_current_user
from auth.jwt_handler import create_access_token
from starlette.templating import Jinja2Templates
from starlette.status import HTTP_302_FOUND
import requests
import ipaddress

templates = Jinja2Templates(directory="templates")
router = APIRouter()

@router.get("/", response_class=HTMLResponse)
def login_page(request: Request, error: str = None):
    return templates.TemplateResponse("login.html", {"request": request, "error": error})

@router.post("/")
def login(
    request: Request,  # Исправлено
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    user = authenticate_user(db, username, password)
    if not user:
        return templates.TemplateResponse("login.html", {"request": request, "error": "Неверный логин или пароль"})
    access_token = create_access_token(data={"sub": username})
    response = RedirectResponse(url="/panel", status_code=HTTP_302_FOUND)
    response.set_cookie(key="auth_token", value=access_token, httponly=True)
    return response

@router.get("/panel", response_class=HTMLResponse)
def admin_panel(request: Request, current_user: dict = Depends(get_current_user)):
    if not current_user:
        return templates.TemplateResponse("auth_required.html", {"request": request})
    return templates.TemplateResponse("panel.html", {"request": request})

@router.get("/panel/stats", response_class=HTMLResponse)
def stats_page(
    request: Request,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    if not current_user:
        return templates.TemplateResponse("auth_required.html", {"request": request})

    stats = db.execute(request_statistics.select()).fetchall()
    stats_data = [
        {
            "id": stat.id,
            "request_time": stat.request_time,
            "source_ip": stat.source_ip,
            "resource": stat.resource,
        }
        for stat in stats
    ]
    return templates.TemplateResponse("stats.html", {"request": request, "stats": stats_data})

@router.get("/panel/resources", response_class=HTMLResponse)
def resources_page(
    request: Request,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    if not current_user:
        return templates.TemplateResponse("auth_required.html", {"request": request})

    blocked_resources = db.execute(
        blocked_entities.select()
    ).fetchall()
    return templates.TemplateResponse("resources.html", {"request": request, "resources": blocked_resources})

@router.post("/panel/resources/add")
def add_blocked_resource(
    request: Request,
    blocked_ip: str = Form(None),
    blocked_domain: str = Form(None),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    if not current_user:
        return templates.TemplateResponse("auth_required.html", {"request": request})

    # Получаем текущие записи для отображения
    blocked_resources = db.execute(blocked_entities.select()).fetchall()

    if not blocked_ip and not blocked_domain:
        return templates.TemplateResponse(
            "resources.html",
            {"request": request, "error": "IP or domain must be provided", "resources": blocked_resources},
        )

    if blocked_ip:
        try:
            ipaddress.ip_address(blocked_ip)
        except ValueError:
            return templates.TemplateResponse(
                "resources.html",
                {"request": request, "error": "Invalid IP address", "resources": blocked_resources},
            )

    if blocked_domain:
        if "." not in blocked_domain:
            return templates.TemplateResponse(
                "resources.html",
                {"request": request, "error": "Invalid domain name", "resources": blocked_resources},
            )

    new_resource = {
        "blocked_ip": blocked_ip,
        "blocked_domain": blocked_domain,
        "resource": "",
        "is_blocked": True,
    }
    db.execute(blocked_entities.insert().values(**new_resource))
    db.commit()
    return RedirectResponse(url="/panel/resources", status_code=HTTP_302_FOUND)

@router.post("/panel/resources/toggle")
def toggle_block_status(data: dict, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    if not current_user:
        return JSONResponse(status_code=401, content={"error": "Unauthorized"})

    resource_id = data.get("id")
    is_blocked = data.get("is_blocked")

    if resource_id is None or is_blocked is None:
        return JSONResponse(status_code=400, content={"error": "Invalid data"})

    # Обновляем состояние в базе данных
    db.execute(
        blocked_entities.update()
        .where(blocked_entities.c.id == resource_id)
        .values(is_blocked=is_blocked)
    )
    db.commit()
    return {"status": "success"}