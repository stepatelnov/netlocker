from .admin_routes import router as admin_router
from .api_routes import router as api_router

__all__ = ["admin_router", "api_router"]