from fastapi import APIRouter, Depends, HTTPException, Body
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from database import request_statistics, blocked_entities, get_db
from auth.password_utils import get_current_user
import psutil
import requests

router = APIRouter()

@router.get("/api/system-status")
def get_system_status():
    cpu_usage = psutil.cpu_percent(interval=1)
    ram_usage = psutil.virtual_memory().percent
    return JSONResponse(content={"cpu_usage": cpu_usage, "ram_usage": ram_usage})

@router.post("/api/toggle-block/{resource_id}")
def toggle_block(resource_id: int, is_blocked: bool, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    if not current_user:
        return {"error": "Not authorized"}
    db.execute(
        blocked_entities.update()
        .where(blocked_entities.c.id == resource_id)
        .values(is_blocked=is_blocked)
    )
    db.commit()
    return {"status": "success"}

@router.post("/api/delete-resource/{resource_id}")
def delete_resource(resource_id: int, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    if not current_user:
        raise HTTPException(status_code=401, detail="Not authorized")
    
    resource = db.execute(
        blocked_entities.select().where(blocked_entities.c.id == resource_id)
    ).fetchone()
    
    if not resource:
        raise HTTPException(status_code=404, detail="Resource not found")
    
    db.execute(
        blocked_entities.delete().where(blocked_entities.c.id == resource_id)
    )
    db.commit()
    
    return {"status": "success", "message": f"Resource {resource_id} deleted"}


def send_mode_request(mode):
    url = 'http://172.17.0.1:5000/mode'
    response = requests.post(url, json={'mode': mode})
    return response.json()

# Маршрут для старт фильтрации
@router.post('/api/startFiltering')
def start_filtering():
    result = send_mode_request(1)  # 1 - Старт
    return result

# Маршрут для остановки фильтрации
@router.post('/api/stopFiltering')
def stop_filtering():
    result = send_mode_request(2)  # 2 - Стоп
    return result

# Маршрут для обновления заблокированных ресурсов
@router.post('/api/updateBlockedResources')
def update_blocked_resources():
    result = send_mode_request(3)  # 3 - Обновление
    return result
