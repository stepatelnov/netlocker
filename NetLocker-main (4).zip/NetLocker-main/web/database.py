from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, Boolean, TIMESTAMP
from sqlalchemy.orm import sessionmaker

from config import DATABASE_URL

# Подключение к базе данных
engine = create_engine(DATABASE_URL)
metadata = MetaData()

# Таблицы
administrators = Table(
    "administrators",
    metadata,
    Column("id", Integer, primary_key=True, index=True),
    Column("username", String, unique=True, index=True),
    Column("password_hash", String),
    Column("created_at", TIMESTAMP),
)

request_statistics = Table(
    "request_statistics",
    metadata,
    Column("id", Integer, primary_key=True, index=True),
    Column("request_time", TIMESTAMP),
    Column("source_ip", String),
    Column("resource", String),
)

blocked_entities = Table(
    "blocked_entities",
    metadata,
    Column("id", Integer, primary_key=True, index=True),
    Column("blocked_ip", String),
    Column("blocked_domain", String),
    Column("resource", String),
    Column("is_blocked", Boolean, default=False),
)

# Настройка сессий
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
