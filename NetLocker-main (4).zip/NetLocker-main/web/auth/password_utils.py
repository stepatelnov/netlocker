from passlib.context import CryptContext
from sqlalchemy.orm import Session
from fastapi import Depends, Cookie
from database import administrators, get_db
from auth.jwt_handler import decode_access_token

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def authenticate_user(db: Session, username: str, password: str):
    user = db.execute(administrators.select().where(administrators.c.username == username)).fetchone()
    if user and verify_password(password, user.password_hash):
        return user
    return None

def get_token_from_cookie(auth_token: str = Cookie(None)):
    return auth_token

def get_current_user(auth_token: str = Depends(get_token_from_cookie), db: Session = Depends(get_db)):
    if not auth_token:
        return None

    payload = decode_access_token(auth_token)
    if not payload:
        return None

    username = payload.get("sub")
    if not username:
        return None

    user = db.execute(administrators.select().where(administrators.c.username == username)).fetchone()
    return user
