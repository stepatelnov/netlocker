from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.templating import Jinja2Templates
from routes.admin_routes import router as admin_router
from routes.api_routes import router as api_router

# Настройка приложения
app = FastAPI()

# Шаблоны
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

# Подключение маршрутов
app.include_router(admin_router)
app.include_router(api_router)
