from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, text
import logging
import os
import signal
import threading
from scapy.all import IP, DNS
from netfilterqueue import NetfilterQueue
import time
from datetime import datetime
from pydantic import BaseModel

# Создаем приложение FastAPI
app = FastAPI()

# Настройка CORS
origins = [
    "http://localhost:8000",  # Разрешаем запросы с фронтенда на порту 8000
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # Разрешаем только эти источники
    allow_credentials=True,
    allow_methods=["*"],  # Разрешаем все HTTP методы
    allow_headers=["*"],  # Разрешаем все заголовки
)

# Конфигурация подключения к базе данных через SQLAlchemy
DATABASE_URL = "postgresql://netlocker:Shrx3yKhg747@localhost:5432/netlockerdb"
engine = create_engine(DATABASE_URL)

# Логгер
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Глобальные списки для блокировки
blocked_ips = set()
blocked_domains = set()
filtering_thread = None

# Создание блокировки для синхронизации
data_lock = threading.Lock()

class ModeRequest(BaseModel):
    mode: int

@app.post("/mode")
async def handle_mode(request: ModeRequest):
    """API для обработки различных режимов: запуск, остановка, обновление фильтрации."""
    mode = request.mode
    
    if mode == 1:  # Старт
        global filtering_thread  # Переносим global перед использованием переменной
        if filtering_thread and filtering_thread.is_alive():
            return {"status": "filtering already running"}
        
        setup_iptables()
        filtering_thread = threading.Thread(target=filter_packets, daemon=True)
        filtering_thread.start()
        return {"status": "filtering started"}

    elif mode == 2:  # Стоп
        cleanup_iptables()
        return {"status": "filtering stopped"}

    elif mode == 3:  # Обновление
        get_blocked_resources_from_db()
        return {"status": "success"}

    else:
        raise HTTPException(status_code=400, detail="Invalid mode")

def get_blocked_resources_from_db():
    """Функция для получения списка заблокированных IP и доменов из базы данных."""
    with engine.connect() as connection:
        query = text("SELECT blocked_ip, blocked_domain FROM blocked_entities WHERE is_blocked = TRUE")
        result = connection.execute(query).fetchall()

    global blocked_ips, blocked_domains
    with data_lock:  # Используем блокировку для безопасного обновления данных
        blocked_ips.clear()
        blocked_domains.clear()

        for row in result:
            if row[0]:
                blocked_ips.add(row[0])
            if row[1]:
                blocked_domains.add(row[1])

    logger.info(f"Fetched blocked resources from DB: IPs: {blocked_ips}, Domains: {blocked_domains}")

def filter_packets():
    """Запуск фильтрации пакетов."""
    nfqueue = NetfilterQueue()
    try:
        nfqueue.bind(1, packet_handler)
        logger.info(f"Started filtering with blocked IPs: {blocked_ips}, blocked domains: {blocked_domains}")
        nfqueue.run()
    except OSError as e:
        logger.error(f"Failed to bind queue: {e}")
    except KeyboardInterrupt:
        logger.info("Stopping filtering.")
    finally:
        nfqueue.unbind()
def packet_handler(packet):
    """Обработчик пакетов из NetfilterQueue."""
    try:
        scapy_packet = IP(packet.get_payload())
        
        # Синхронизация доступа к спискам блокировок
        with data_lock:
            src_ip = scapy_packet.src
            dst_ip = scapy_packet.dst
            
            # Блокировка по IP
            if src_ip in blocked_ips or dst_ip in blocked_ips:
                logger.info(f"Blocking packet from/to IP: {src_ip} -> {dst_ip}")
                log_request_to_db(src_ip, dst_ip)
                packet.drop()
                return
            
            # Проверка DNS-запросов
            if scapy_packet.haslayer(DNS) and scapy_packet[DNS].qd:
                domain = scapy_packet[DNS].qd.qname.decode(errors='ignore').strip(".")
                if domain in blocked_domains:
                    logger.info(f"Blocking DNS request for domain: {domain}")
                    log_request_to_db(src_ip, domain)
                    packet.drop()
                    return
        
        packet.accept()
    except Exception as e:
        logger.error(f"Error handling packet: {e}")
        packet.accept()

def log_request_to_db(source_ip, resource):
    """Логирование запроса в базу данных."""
    if resource:
        try:
            with engine.connect() as connection:
                # Вставка в таблицу
                query = text("""
                    INSERT INTO request_statistics (source_ip, resource)
                    VALUES (:source_ip, :resource)
                """)
                connection.execute(query, {"source_ip": source_ip, "resource": resource})
                connection.commit()  # Явное подтверждение транзакции
            logger.info(f"Logged request to DB: source_ip={source_ip}, resource={resource}")
        except Exception as e:
            logger.error(f"Error logging request to DB: {e}")

def setup_iptables():
    """Настройка правил iptables для перенаправления трафика в NetfilterQueue."""
    os.system("iptables -F")
    os.system("iptables -A INPUT -p tcp --dport 80 -j NFQUEUE --queue-num 1")
    os.system("iptables -A INPUT -p udp --dport 53 -j NFQUEUE --queue-num 1")
    os.system("iptables -A OUTPUT -p tcp --sport 80 -j NFQUEUE --queue-num 1")
    os.system("iptables -A OUTPUT -p udp --sport 53 -j NFQUEUE --queue-num 1")
    os.system("iptables -A FORWARD -j NFQUEUE --queue-num 1")
    logger.info("Iptables rules set up for NFQUEUE.")

def cleanup_iptables():
    """Удаление правил iptables при завершении работы."""
    os.system("iptables -D INPUT -p tcp --dport 80 -j NFQUEUE --queue-num 1")
    os.system("iptables -D INPUT -p udp --dport 53 -j NFQUEUE --queue-num 1")
    os.system("iptables -D OUTPUT -p tcp --sport 80 -j NFQUEUE --queue-num 1")
    os.system("iptables -D OUTPUT -p udp --sport 53 -j NFQUEUE --queue-num 1")
    os.system("iptables -D FORWARD -j NFQUEUE --queue-num 1")
    logger.info("Iptables rules cleaned up.")

def signal_handler(sig, frame):
    """Обработчик сигналов для корректного завершения работы."""
    logger.info("Shutting down...")
    cleanup_iptables()
    os._exit(0)

if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Запуск FastAPI с использованием Uvicorn
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)

